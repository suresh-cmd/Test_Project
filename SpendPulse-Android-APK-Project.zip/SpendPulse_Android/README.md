# SpendPulse - Android Native APK Project

This is the complete Android Studio project for **SpendPulse**, configured with native SMS broadcast receiver permissions and full hardware-accelerated WebView.

---

## 3 Easy Ways to Get Your APK

### Option 1: Instant APK via PWA Builder (No Coding Required - 1 Minute)
1. Upload `app/src/main/assets/index.html` to any web host (GitHub Pages, Vercel, Netlify) or use the hosted link.
2. Go to **[PWABuilder.com](https://www.pwabuilder.com/)**.
3. Enter your web app URL and click **Build APK / Android Package**.
4. Download the signed `.apk` directly to your Android device and install it!

---

### Option 2: Build APK via Android Studio (Standard Native APK)
1. Download and extract this project folder.
2. Open **Android Studio** and select **Open Project** -> select this `SpendPulse_Android` folder.
3. Wait for Gradle sync to complete.
4. Click **Build** in the top menu -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
5. Android Studio will generate the file:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer `app-debug.apk` to your Android phone via USB, WhatsApp, or Google Drive and tap **Install**!

---

### Option 3: Free Automatic Cloud APK Build via GitHub
1. Create a new GitHub repository and push this folder to GitHub.
2. Go to the **Actions** tab on your GitHub repository.
3. The workflow `.github/workflows/build-apk.yml` will automatically compile the APK in the cloud.
4. Download the finished `app-debug.apk` directly from the workflow artifacts!

---

## Features Enabled in this Android Project
- **Background SMS Listening**: `SmsReceiver.java` intercepts bank SMS alerts and passes them directly to `index.html` via `window.onNativeSmsReceived()`.
- **Offline Capable**: All assets and HTML are embedded in `app/src/main/assets/index.html`, meaning the app runs smoothly with zero internet required.
- **Dedicated Cash Spent & Income Buttons**: One-tap logging for paper cash transactions and money income funds in Indian Rupees (₹).
